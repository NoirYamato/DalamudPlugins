using AnoMech.Core.SimObjects;

namespace AnoMech.Core.Game.Ai;

// A scenario AI ("strat") — one selectable party-movement choreography. A scenario
// can expose several; the user picks one in the main window before Start.
//
// The non-generic view carries only what the UI needs (the display Name) so strats
// of different scenarios can be listed uniformly. The generic subtype carries the
// actual entry point: state arrives via Run (not the constructor), so a strat is a
// strategy constructed once and fed the per-run state at start. Anything a strat keeps
// between Ticks must be reset by Run, or it leaks into the next attempt.
public interface IScenarioAi
{
    string Name { get; }

    // Optional region/group this strat belongs to. Used by the main-window strat
    // picker to bucket strats under region buttons; must match one of the scenario's
    // IScenario.StratGroups. Null = ungrouped (scenario shows no region row).
    string? Group => null;
}

public interface IScenarioAi<TState> : IScenarioAi
{
    void Run(TState state, SimWorld world);
    // For a strat that reacts to the run rather than following the timeline; the scenario's own
    // Tick calls it.
    void Tick(TState state, SimWorld world, float delta) { }
}
