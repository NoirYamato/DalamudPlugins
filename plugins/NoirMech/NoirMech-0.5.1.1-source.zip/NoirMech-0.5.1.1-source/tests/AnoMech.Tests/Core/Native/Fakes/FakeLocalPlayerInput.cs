using System;
using System.Collections.Generic;
using AnoMech.Core.Native.Interfaces;
using FFXIVClientStructs.FFXIV.Client.Game;

namespace AnoMech.Tests;

// Nobody at the keyboard, unless a test holds a movement key.
internal sealed class FakeLocalPlayerInput : ILocalPlayerInput
{
    public event Action<ActionType, uint, ulong>? ActionExecuted { add { } remove { } }

    public bool MovementInputActive { get; set; }
    public bool IsJumping => false;
    public bool IsAutoAttacking => false;
    public bool ActionsBlocked { get; set; }
    public bool PollActionUsed() => false;
    public bool PollCancelCast() => false;
    public IReadOnlyCollection<(uint ActionId, ActionType Type)> RecentActions => [];

    public System.Numerics.Vector2? SteerDirection { get; private set; }
    public float SteerSpeed { get; private set; }

    public void Steer(System.Numerics.Vector2? direction, float speed)
    {
        SteerDirection = direction is { } d && d.LengthSquared() > 0f ? System.Numerics.Vector2.Normalize(d) : null;
        SteerSpeed = speed;
    }
    public void Dispose() { }
}
