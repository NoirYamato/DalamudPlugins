using System.Globalization;
using MitCue.Core.Actions;
using MitCue.Core.Fights;
using MitCue.Core.Plans;

namespace MitCue.Core.Reminders;

/// <summary>
/// Turns the player's plan entries into reminders and advances their states from timeline time,
/// own action uses and cooldown information. Pure logic: no clock, no game access.
/// </summary>
/// <remarks>
/// <para>
/// Building (docs/DESIGN.md §5.1): one <see cref="Reminder"/> per item of every entry whose
/// mechanic exists in the fight (other entries are reported in <see cref="Problems"/>). All items of
/// an entry share its press time, hit + offset; without an explicit offset the default comes from
/// the entry's timing action, i.e. the first item action the catalog resolves (for an either-or
/// item: its first resolvable option). Each item's use window comes from its own timing action.
/// </para>
/// <para>
/// States (§5.2) only move forward on <see cref="Update"/>: Pending → Upcoming → Due → Missed (or
/// Passed for notes and optional entries); <see cref="OnOwnAction"/> marks Done and
/// <see cref="OnTimelineJump"/> marks Skipped, or Due for phase-end reminders at the transition that
/// ends their phase. Only a backward jump of more than 5 s or <see cref="Reset"/> moves reminders back
/// to Pending.
/// </para>
/// <para>
/// Not thread-safe: call every member from one thread (or synchronize externally).
/// <see cref="BecameDue"/> handlers run synchronously inside <see cref="Update"/>.
/// <see cref="ReminderOptions.Lookahead"/>, <see cref="ReminderOptions.DueLead"/>,
/// <see cref="ReminderOptions.KeepFinishedFor"/> and <see cref="ReminderOptions.ShowSkipped"/> are read
/// live (lookahead and due lead also widen the start of a use's matching window, see
/// <see cref="OnOwnAction"/>), and so is <see cref="ReminderOptions.HealLateWindow"/> for the phase-end
/// grace; <see cref="Reminder.Earliest"/> and <see cref="Reminder.Latest"/> are fixed when the scheduler
/// is built, except that a phase transition moves the latest of the phase-end reminders it makes due.
/// </para>
/// </remarks>
public sealed class ReminderScheduler
{
    /// <summary>Capacity of <see cref="RecentUses"/>.</summary>
    public const int RecentUsesCapacity = 50;

    /// <summary>
    /// A phase-end reminder made due by a phase transition stays due at least this long after it (or
    /// <see cref="ReminderOptions.HealLateWindow"/> when that is longer), see <see cref="OnTimelineJump"/>.
    /// </summary>
    public const double MinPhaseEndGrace = 8;

    /// <summary>Lateness below this is not reported in <see cref="Reminder.ReadyIn"/>.</summary>
    private const double ReadyInThreshold = 0.25;

    /// <summary>Backward time corrections up to this size are normal sync jitter, not rewinds.</summary>
    private const double SmallBackwardCorrection = 5;

    private readonly Track[] tracks;
    private readonly double[] phaseStarts;
    private readonly List<Reminder> visibleBuffer = [];
    private readonly List<ActionUse> recentUses = new(RecentUsesCapacity);

    public ReminderScheduler(FightDefinition fight, IEnumerable<PlanEntry> entries, IActionCatalog actions, ReminderOptions options)
    {
        ArgumentNullException.ThrowIfNull(fight);
        ArgumentNullException.ThrowIfNull(entries);
        ArgumentNullException.ThrowIfNull(actions);
        ArgumentNullException.ThrowIfNull(options);

        this.Fight = fight;
        this.Options = options;
        this.phaseStarts = fight.Phases.Select(p => p.Start).Distinct().Order().ToArray();

        var problems = new List<string>();
        this.tracks = Build(fight, entries, actions, options, problems);
        this.All = Array.AsReadOnly(Array.ConvertAll(this.tracks, t => t.Reminder));
        this.Problems = problems.AsReadOnly();
        this.RecentUses = this.recentUses.AsReadOnly();
    }

    public FightDefinition Fight { get; }

    public ReminderOptions Options { get; }

    /// <summary>All reminders of the pull, ordered by press time (then plan entry order, then item index).</summary>
    public IReadOnlyList<Reminder> All { get; }

    /// <summary>Plan entries that could not be scheduled (unknown mechanic), one message each.</summary>
    public IReadOnlyList<string> Problems { get; }

    /// <summary>
    /// The last <see cref="RecentUsesCapacity"/> own action uses, oldest first, each with the reminder it
    /// satisfied (null when the use was outside every window and therefore ignored). For debugging.
    /// </summary>
    public IReadOnlyList<ActionUse> RecentUses { get; }

    /// <summary>Raised once when a reminder becomes Due (the plugin plays a sound).</summary>
    /// <remarks>
    /// Not raised for reminders that finish (Missed/Passed) in the same update. Raised again only
    /// after the reminder went back to Pending: <see cref="Reset"/>, or a backward jump that reopened
    /// it (see <see cref="OnTimelineJump"/>; a reminder still due at the jump target stays Due and is
    /// not raised twice). A phase-end reminder that a phase transition makes Due is announced by the
    /// next <see cref="Update"/>, once (not again if it was already due before the transition).
    /// </remarks>
    public event Action<Reminder>? BecameDue;

    /// <summary>Back to the start of a pull (all reminders Pending, with their planned use windows).</summary>
    public void Reset()
    {
        foreach (var track in this.tracks)
        {
            track.RestorePlannedWindow();
            track.Rearm();
            var r = track.Reminder;
            r.UsedAt = null;
            r.UsedActionId = null;
            r.UsedEarly = false;
        }
        this.recentUses.Clear();
        this.visibleBuffer.Clear();
    }

    /// <summary>
    /// The timeline jumped from <paramref name="fromTime"/> to <paramref name="toTime"/> (phase push,
    /// resync or loop): reminders the jump made pointless are Skipped, phase-end reminders of the phase
    /// it ends become Due, rewound ones are reopened.
    /// </summary>
    /// <param name="fromTime">
    /// Timeline time before the jump, or −∞ for a jump from nowhere: a bulk skip of everything before
    /// <paramref name="toTime"/>, or a timeline that started from stopped (e.g. a pull joined mid-fight). Pass such
    /// a start as a jump from −∞, not from 0: it skips what it passed and never ends a phase (the plugin's session
    /// does so).
    /// </param>
    /// <param name="toTime">Timeline time after the jump.</param>
    /// <remarks>
    /// <para>
    /// Forward jump: a Pending/Upcoming reminder whose press time lies in (from, to] becomes Skipped
    /// (finished at <paramref name="toTime"/>) when the jump also passed its hit (hit in (from, to])
    /// or its use window (latest &lt; to). The others can still be done in time, typically for the
    /// mechanic right after a phase-start sync, so they are left as they are: the next
    /// <see cref="Update"/> makes them Due and raises <see cref="BecameDue"/>. Due and finished
    /// reminders are left alone.
    /// </para>
    /// <para>
    /// Phase-end reminders (<see cref="Reminder.IsPhaseEnd"/>: the entry is flagged
    /// <see cref="PlanEntry.AtPhaseEnd"/> or anchored to an enrage) are the exception (docs/DESIGN.md §5.2): the
    /// jump that ends their phase is exactly when they should be pressed. Such a reminder, not finished and not
    /// made due by an earlier transition, is caught by a forward jump that
    /// </para>
    /// <list type="bullet">
    /// <item>reached its press time (press ≤ to; it may already be Upcoming or Due),</item>
    /// <item>passed its hit or its planned use window (hit in (from, to], or latest &lt; to), and</item>
    /// <item>starts in the phase its press time belongs to (a press exactly at a phase start belongs to the phase
    /// ending there) and lands in that phase or the next one: a phase push, or a push inside the phase that ends a
    /// stage of it before its enrage (TEA P3: killing the adds of the DPS check jumps over the Eternal Darkness enrage
    /// to 771.9, still in P3). In a fight without phases every such jump counts. The other jumps skip it by the rule
    /// above: one that starts in another phase, one that lands two or more phases on (a preview that cuts whole
    /// phases), and one from −∞ (a bulk skip, or a timeline that started from stopped, see
    /// <paramref name="fromTime"/>).</item>
    /// </list>
    /// <para>
    /// It becomes Due at once, <see cref="Reminder.Latest"/> moves to max(latest, to + grace), where grace =
    /// max(<see cref="ReminderOptions.HealLateWindow"/>, <see cref="MinPhaseEndGrace"/>), and
    /// <see cref="Reminder.PhaseEndDueAt"/> is set to <paramref name="toTime"/>. The next <see cref="Update"/>
    /// raises <see cref="BecameDue"/> (only once: not if it was already due before the jump, nor if it finishes in
    /// that update); after the new latest it is Missed (Passed for notes and optional entries) as usual.
    /// </para>
    /// <para>
    /// Backward jump of more than 5 s: every reminder that is not Done and whose use window is still
    /// open at <paramref name="toTime"/> (latest ≥ to) goes back to Pending, and the next
    /// <see cref="Update"/> re-derives Upcoming/Due from the new time. The exception is a Due reminder
    /// that is still due at <paramref name="toTime"/>: it stays Due (no flicker, no second
    /// <see cref="BecameDue"/>). Reminders that stay finished (Done, or with their window over at the
    /// target) keep their outcome but are no longer listed by <see cref="Update"/>, because their
    /// finished row belongs to the timeline before the rewind. A phase-end reminder made due by a
    /// transition keeps its moved latest, unless the jump goes back before its due time
    /// (to &lt; press − due lead): then it gets its planned window back, and the next transition can make it
    /// due again.
    /// Smaller backward corrections change nothing.
    /// </para>
    /// </remarks>
    public void OnTimelineJump(double fromTime, double toTime)
    {
        if (toTime > fromTime)
        {
            var grace = Math.Max(this.Options.HealLateWindow, MinPhaseEndGrace);
            foreach (var track in this.tracks)
            {
                var r = track.Reminder;
                if (this.EndsPhaseOf(track, fromTime, toTime))
                {
                    // Due now; Advance raises BecameDue on the next update unless it was already due (DueRaised).
                    track.CatchAtPhaseEnd(toTime, Math.Max(track.PlannedLatest, toTime + grace));
                    r.State = ReminderState.Due;
                    continue;
                }

                if ((r.State is ReminderState.Pending or ReminderState.Upcoming)
                    && r.PressAt > fromTime && r.PressAt <= toTime
                    && ((r.Hit > fromTime && r.Hit <= toTime) || r.Latest < toTime))
                {
                    Finish(r, ReminderState.Skipped, toTime);
                }
            }
        }
        else if (toTime < fromTime - SmallBackwardCorrection)
        {
            foreach (var track in this.tracks)
            {
                var r = track.Reminder;

                // Back before its due time: the transition that made it due has to happen again.
                if (r.PhaseEndDueAt != null && toTime < r.PressAt - this.Options.DueLead)
                    track.RestorePlannedWindow();

                if (r.State == ReminderState.Done || r.Latest < toTime)
                {
                    // The outcome stands, but its finished row is from before the rewind.
                    if (IsFinished(r.State))
                        track.HideFinished = true;
                    continue;
                }

                if (r.State == ReminderState.Due && toTime >= r.PressAt - this.Options.DueLead)
                    track.RestartReadiness(); // still due: keep it (and its sound) as is
                else if (r.State != ReminderState.Pending)
                    track.Rearm();
            }
        }
    }

    /// <summary>The local player used an action at the given timeline time.</summary>
    /// <remarks>
    /// The use satisfies at most one reminder: the not-finished action reminder with the smallest
    /// press time whose item contains the action and whose use window contains the time. The window
    /// starts at the earlier of <see cref="Reminder.Earliest"/> and the moment the reminder is shown
    /// (press − max(lookahead, due lead)), so a display setting never turns a use that covers the hit,
    /// or a press on "NOW", into a miss. It ends at <see cref="Reminder.Latest"/> (for when-ready
    /// entries, as extended by <see cref="Update"/> while waiting for the cooldown); both ends are
    /// inclusive. The reminder becomes Done; a use before <see cref="Reminder.Earliest"/> is flagged
    /// <see cref="Reminder.UsedEarly"/>. Every use is recorded in <see cref="RecentUses"/>.
    /// </remarks>
    public void OnOwnAction(uint actionId, double timelineTime)
    {
        var t = timelineTime;
        Reminder? matched = null;
        foreach (var track in this.tracks)
        {
            var r = track.Reminder;
            if (IsFinished(r.State)
                || t < this.UseWindowStart(r)
                || t > track.Deadline
                || !Contains(track.ActionIds, actionId))
            {
                continue;
            }

            r.State = ReminderState.Done;
            r.UsedAt = t;
            r.UsedActionId = actionId;
            r.UsedEarly = t < r.Earliest;
            r.FinishedAt = t;
            r.ReadyIn = null;
            r.MissingResources = false;
            matched = r;
            break;
        }

        if (this.recentUses.Count >= RecentUsesCapacity)
            this.recentUses.RemoveAt(0);
        this.recentUses.Add(new ActionUse(actionId, t, matched));
    }

    /// <summary>Advances states to <paramref name="timelineTime"/> and returns the reminders to display, ordered by press time.</summary>
    /// <remarks>
    /// <para>
    /// Visible: Upcoming and Due reminders, plus Done and Missed ones (and Skipped ones when
    /// <see cref="ReminderOptions.ShowSkipped"/>) for <see cref="ReminderOptions.KeepFinishedFor"/>
    /// seconds after they finished. A finished row also stays listed when time is corrected back by
    /// up to 5 s (sync jitter, so rows do not flicker), but a backward jump of more than 5 s hides
    /// the rows of reminders it leaves finished (see <see cref="OnTimelineJump"/>). The result is a
    /// new snapshot; it is not changed by later calls.
    /// </para>
    /// <para>
    /// Cooldown awareness (Upcoming/Due action reminders, first option of the item):
    /// <see cref="Reminder.ReadyIn"/> is how many seconds after the later of the press time and now
    /// the action becomes ready (reported when more than 0.25 s), and
    /// <see cref="Reminder.MissingResources"/> is set when <paramref name="cooldowns"/> reports a missing
    /// job resource. When-ready entries stay Due past <see cref="Reminder.Latest"/> while the action is
    /// reported on cooldown; once it is ready they get max(latest − now, heal late window) more seconds.
    /// </para>
    /// </remarks>
    public IReadOnlyList<Reminder> Update(double timelineTime, ICooldownProvider? cooldowns = null)
    {
        foreach (var track in this.tracks)
            this.Advance(track, timelineTime, cooldowns);
        return this.CollectVisible(timelineTime);
    }

    /// <summary>
    /// Counts over action reminders of non-optional entries (notes and optional entries are never
    /// counted): Total = Done + Missed, Skipped, and the missed reminders ordered by press time.
    /// </summary>
    public PullSummary Summarize()
    {
        int done = 0, missed = 0, skipped = 0;
        var missedReminders = new List<Reminder>();
        foreach (var track in this.tracks)
        {
            var r = track.Reminder;
            if (!track.IsAction || r.Entry.Optional)
                continue;
            switch (r.State)
            {
                case ReminderState.Done:
                    done++;
                    break;
                case ReminderState.Missed:
                    missed++;
                    missedReminders.Add(r);
                    break;
                case ReminderState.Skipped:
                    skipped++;
                    break;
            }
        }
        return new PullSummary(done + missed, done, missed, skipped, missedReminders.AsReadOnly());
    }

    private static Track[] Build(FightDefinition fight, IEnumerable<PlanEntry> entries, IActionCatalog actions, ReminderOptions options, List<string> problems)
    {
        var built = new List<Track>();
        var entryIndex = -1;
        foreach (var entry in entries)
        {
            entryIndex++;
            if (entry == null)
                continue;

            var mechanic = fight.GetMechanic(entry.Mechanic);
            if (mechanic == null)
            {
                problems.Add(DescribeUnknownMechanic(fight, entry, entryIndex));
                continue;
            }
            if (entry.Do is not { Count: > 0 } items)
                continue;

            var hit = mechanic.HitAt(entry.HitIndex ?? 0);

            // Items of one entry share the press time; without an explicit offset it follows the
            // first item whose action the catalog knows.
            var timing = new ActionInfo?[items.Count];
            ActionInfo? entryTiming = null;
            for (var i = 0; i < items.Count; i++)
            {
                timing[i] = items[i] is { } item ? FirstResolvable(item, actions) : null;
                entryTiming ??= timing[i];
            }
            var pressAt = hit + (entry.Offset ?? TimingRules.DefaultOffset(entryTiming, fight.SyncLevel));

            for (var i = 0; i < items.Count; i++)
            {
                if (items[i] is not { } item)
                    continue;
                var (earliest, latest) = TimingRules.UseWindow(timing[i], fight.SyncLevel, hit, pressAt, options);
                var reminder = new Reminder
                {
                    Entry = entry,
                    Item = item,
                    ItemIndex = i,
                    Mechanic = mechanic,
                    Hit = hit,
                    PressAt = pressAt,
                    Earliest = earliest,
                    Latest = latest,
                };
                built.Add(new Track(reminder, entryIndex));
            }
        }

        // (press time, entry order, item index) is a total order, so the unstable sort is deterministic.
        built.Sort(CompareTracks);
        return built.ToArray();
    }

    /// <summary>The timing action of an item: its action, or the first option of an either-or item the catalog resolves.</summary>
    private static ActionInfo? FirstResolvable(PlanItem item, IActionCatalog actions)
    {
        foreach (var id in item.ActionIds())
        {
            if (actions.Get(id) is { } action)
                return action;
        }
        return null;
    }

    private static string DescribeUnknownMechanic(FightDefinition fight, PlanEntry entry, int entryIndex)
    {
        var name = string.IsNullOrEmpty(entry.Id) ? "#" + (entryIndex + 1).ToString(CultureInfo.InvariantCulture) : "'" + entry.Id + "'";
        var src = string.IsNullOrEmpty(entry.Src) ? string.Empty : " (" + entry.Src + ")";
        return $"Entry {name}{src}: unknown mechanic '{entry.Mechanic}' in fight '{fight.Key}'; skipped.";
    }

    private static int CompareTracks(Track a, Track b)
    {
        var c = a.Reminder.PressAt.CompareTo(b.Reminder.PressAt);
        if (c != 0)
            return c;
        c = a.EntryIndex.CompareTo(b.EntryIndex);
        return c != 0 ? c : a.Reminder.ItemIndex.CompareTo(b.Reminder.ItemIndex);
    }

    private static bool IsFinished(ReminderState state) =>
        state is ReminderState.Done or ReminderState.Missed or ReminderState.Skipped or ReminderState.Passed;

    private static void Finish(Reminder r, ReminderState state, double at)
    {
        r.State = state;
        r.FinishedAt = at;
        r.ReadyIn = null;
        r.MissingResources = false;
    }

    private static bool Contains(IReadOnlyList<uint> ids, uint id)
    {
        for (var i = 0; i < ids.Count; i++)
        {
            if (ids[i] == id)
                return true;
        }
        return false;
    }

    /// <summary>
    /// Seconds the action becomes ready after the later of the press time and now (so a ready action
    /// is never reported late), or null when unknown or not more than <see cref="ReadyInThreshold"/>.
    /// </summary>
    private static double? Lateness(double? secondsUntilReady, double pressAt, double t)
    {
        if (secondsUntilReady is not { } wait)
            return null;
        var late = wait - Math.Max(pressAt - t, 0);
        return late > ReadyInThreshold ? late : null;
    }

    /// <summary>
    /// Where the use window starts: the earlier of <see cref="Reminder.Earliest"/> and the moment the
    /// reminder is shown, Upcoming or Due (press − max(lookahead, due lead)).
    /// </summary>
    private double UseWindowStart(Reminder r) =>
        Math.Min(r.Earliest, r.PressAt - Math.Max(this.Options.Lookahead, this.Options.DueLead));

    /// <summary>
    /// True when the forward jump from <paramref name="from"/> to <paramref name="to"/> ends the phase (or the stage
    /// of it) of a phase-end reminder that is still waiting to be pressed (the conditions are listed on
    /// <see cref="OnTimelineJump"/>).
    /// </summary>
    private bool EndsPhaseOf(Track track, double from, double to)
    {
        var r = track.Reminder;
        return r.IsPhaseEnd
            && r.PhaseEndDueAt == null
            && !IsFinished(r.State)
            && double.IsFinite(from)
            && r.PressAt <= to
            && ((r.Hit > from && r.Hit <= to) || track.PlannedLatest < to)
            && this.StartsInPhaseAndLandsInItOrTheNext(r.PressAt, from, to);
    }

    /// <summary>
    /// True when a jump from <paramref name="from"/> to <paramref name="to"/> starts in the phase <paramref name="pressAt"/>
    /// belongs to (a press exactly at a phase start belongs to the phase ending there) and lands in that phase or the
    /// one right after it. Always true for a fight without phases; never for a press time before the first phase.
    /// </summary>
    private bool StartsInPhaseAndLandsInItOrTheNext(double pressAt, double from, double to)
    {
        if (this.phaseStarts.Length == 0)
            return true;

        int beforePress = 0, startedAtFrom = 0, startedAtTo = 0;
        foreach (var start in this.phaseStarts)
        {
            if (start < pressAt)
                beforePress++;
            if (start <= from)
                startedAtFrom++;
            if (start <= to)
                startedAtTo++;
        }
        return beforePress > 0
            && startedAtFrom == beforePress
            && (startedAtTo == beforePress || startedAtTo == beforePress + 1);
    }

    private void Advance(Track track, double t, ICooldownProvider? cooldowns)
    {
        var r = track.Reminder;
        if (IsFinished(r.State))
            return;

        var options = this.Options;
        var isAction = track.IsAction;

        // Cooldown of the item's first option, for reminders that are (becoming) visible or overdue.
        double? secondsUntilReady = null;
        if (isAction && cooldowns != null && (t >= r.PressAt - options.Lookahead || t > track.Deadline))
            secondsUntilReady = cooldowns.SecondsUntilReady(track.PrimaryActionId);

        if (isAction && r.Entry.WhenReady && secondsUntilReady is { } wait)
            track.ObserveReadiness(wait, t, options.HealLateWindow);

        if (t > track.Deadline)
        {
            Finish(r, isAction && !r.Entry.Optional ? ReminderState.Missed : ReminderState.Passed, t);
            return;
        }

        // Due from press − due lead on, or already (a phase transition makes phase-end reminders due at once and
        // leaves the announcement to this update). Announced once until the reminder goes back to Pending.
        var becameDue = false;
        if (t >= r.PressAt - options.DueLead || r.State == ReminderState.Due)
        {
            r.State = ReminderState.Due;
            becameDue = !track.DueRaised;
            track.DueRaised = true;
        }
        else if (r.State == ReminderState.Pending && t >= r.PressAt - options.Lookahead)
        {
            r.State = ReminderState.Upcoming;
        }

        if (isAction && r.State is ReminderState.Upcoming or ReminderState.Due)
        {
            r.ReadyIn = Lateness(secondsUntilReady, r.PressAt, t);
            r.MissingResources = cooldowns?.HasResources(track.PrimaryActionId) == false;
        }
        else
        {
            r.ReadyIn = null;
            r.MissingResources = false;
        }

        if (becameDue)
            this.RaiseBecameDue(r);
    }

    private IReadOnlyList<Reminder> CollectVisible(double t)
    {
        var buffer = this.visibleBuffer;
        buffer.Clear();
        foreach (var track in this.tracks)
        {
            if (this.IsVisible(track, t))
                buffer.Add(track.Reminder);
        }
        return buffer.Count == 0 ? Array.Empty<Reminder>() : buffer.ToArray();
    }

    private bool IsVisible(Track track, double t) => track.Reminder.State switch
    {
        ReminderState.Upcoming or ReminderState.Due => true,
        ReminderState.Done or ReminderState.Missed => this.RecentlyFinished(track, t),
        ReminderState.Skipped => this.Options.ShowSkipped && this.RecentlyFinished(track, t),
        _ => false,
    };

    /// <summary>
    /// Finished at most KeepFinishedFor ago (tolerating small backward time corrections), and not
    /// before a backward jump that left it finished.
    /// </summary>
    private bool RecentlyFinished(Track track, double t) =>
        !track.HideFinished
        && track.Reminder.FinishedAt is { } at
        && t - at <= this.Options.KeepFinishedFor
        && at - t <= SmallBackwardCorrection;

    private void RaiseBecameDue(Reminder r) => this.BecameDue?.Invoke(r);

    /// <summary>A reminder plus the scheduler's private bookkeeping for it.</summary>
    private sealed class Track
    {
        public Track(Reminder reminder, int entryIndex)
        {
            this.Reminder = reminder;
            this.EntryIndex = entryIndex;
            this.ActionIds = reminder.ActionIds;
            this.PlannedLatest = reminder.Latest;
            this.Deadline = reminder.Latest;
        }

        public Reminder Reminder { get; }

        /// <summary>Position of the entry in the plan (tie-breaker for equal press times).</summary>
        public int EntryIndex { get; }

        /// <summary>The end of the use window as built (<see cref="Reminder.Latest"/> before a phase transition moved it).</summary>
        public double PlannedLatest { get; }

        public IReadOnlyList<uint> ActionIds { get; }

        public bool IsAction => this.ActionIds.Count > 0;

        /// <summary>The item's first option: the action whose cooldown and resources are checked.</summary>
        public uint PrimaryActionId => this.ActionIds[0];

        /// <summary>
        /// After this the reminder is missed: <see cref="Reminder.Latest"/>, or later for a when-ready
        /// entry whose action was on cooldown (infinite while it still is).
        /// </summary>
        public double Deadline { get; private set; }

        /// <summary>When-ready entries: first time the action was seen ready (in the current ready streak).</summary>
        public double? ReadySince { get; private set; }

        /// <summary><see cref="ReminderScheduler.BecameDue"/> was raised since the reminder last left Pending.</summary>
        public bool DueRaised { get; set; }

        /// <summary>
        /// A backward jump of more than 5 s left the reminder finished: its finished row is from the
        /// timeline before the rewind and is not listed again (until <see cref="Rearm"/>).
        /// </summary>
        public bool HideFinished { get; set; }

        /// <summary>When-ready entries: stay due while the action is on cooldown; once ready, allow max(latest − now, grace).</summary>
        public void ObserveReadiness(double secondsUntilReady, double t, double grace)
        {
            if (secondsUntilReady > 0)
            {
                this.ReadySince = null;
                this.Deadline = double.PositiveInfinity;
            }
            else
            {
                this.ReadySince ??= t;
                this.Deadline = Math.Max(this.Reminder.Latest, this.ReadySince.Value + grace);
            }
        }

        /// <summary>When-ready entries: forget the cooldown observations (the next update observes again).</summary>
        public void RestartReadiness()
        {
            this.ReadySince = null;
            this.Deadline = this.Reminder.Latest;
        }

        /// <summary>
        /// A phase transition to <paramref name="jumpTo"/> made this phase-end reminder due until
        /// <paramref name="latest"/> (the deadline never shrinks: a when-ready entry may still be waiting).
        /// </summary>
        public void CatchAtPhaseEnd(double jumpTo, double latest)
        {
            this.Reminder.PhaseEndDueAt = jumpTo;
            this.Reminder.SetLatest(latest);
            this.Deadline = Math.Max(this.Deadline, latest);
        }

        /// <summary>Undoes <see cref="CatchAtPhaseEnd"/>: the planned use window again (no-op when not caught).</summary>
        public void RestorePlannedWindow()
        {
            if (this.Reminder.PhaseEndDueAt == null)
                return;
            this.Reminder.PhaseEndDueAt = null;
            this.Reminder.SetLatest(this.PlannedLatest);
            this.RestartReadiness();
        }

        /// <summary>Back to Pending with no outcome (the usage of Done reminders is cleared separately).</summary>
        public void Rearm()
        {
            var r = this.Reminder;
            r.State = ReminderState.Pending;
            r.FinishedAt = null;
            r.ReadyIn = null;
            r.MissingResources = false;
            this.DueRaised = false;
            this.HideFinished = false;
            this.RestartReadiness();
        }
    }
}
