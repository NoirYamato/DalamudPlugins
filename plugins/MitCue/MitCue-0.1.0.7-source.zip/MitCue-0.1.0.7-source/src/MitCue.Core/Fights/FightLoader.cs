using System.Globalization;
using System.Text;
using MitCue.Core.Data;
using MitCue.Core.Timelines;
using YamlDotNet.RepresentationModel;

namespace MitCue.Core.Fights;

/// <summary>Reads the fight YAML schema documented in docs/DESIGN.md §3.1.</summary>
/// <remarks>
/// <para>Keys are snake_case; unknown keys are ignored so fight files can carry extra notes.</para>
/// <para>
/// Required: <c>fight</c>, <c>name</c>, <c>territory</c>, <c>sync_level</c>, <c>timeline</c>; per phase <c>id</c> and
/// <c>start</c>; per mechanic <c>id</c> and <c>hit</c> (or <c>hits</c>). A mechanic without <c>phase</c> belongs to the
/// phase containing its hit; without <c>name</c> it is named after its <c>entry</c> (or id); without <c>hits</c> it has
/// the single hit <c>[hit]</c>; without <c>kind</c> it is <see cref="MechanicKind.Other"/>.
/// </para>
/// <para>
/// Checked: unique phase and mechanic ids (case-insensitive), mechanics only reference defined phases, <c>hits</c> are
/// in time order and the first of them is <c>hit</c>. Mechanics are returned sorted by hit time (ties keep file order).
/// </para>
/// <para>
/// Optional per mechanic <c>sub_hits</c> (<see cref="Mechanic.SubHits"/>): later damage times that are no timeline entries,
/// which only multi-hit coverage counts; each after <c>hit</c>, in time order, and none of them one of <c>hits</c>.
/// </para>
/// <para>
/// Optional sheet presets: <c>calibration</c> (sheet key → phase id → timeline seconds of sheet 0:00) and
/// <c>row_offsets</c> (sheet key → mechanic id → seconds from the mechanic's first hit to the event the sheet's row time
/// marks, see <see cref="FightDefinition.RowOffsets"/>; the mechanic ids must exist).
/// </para>
/// <para>
/// Optional <c>timeline_additions</c>: cactbot timeline sync lines appended to the timeline when it is loaded
/// (<see cref="FightDefinition.TimelineAdditions"/>); every line must be an entry with a sync and no label jump (no label
/// or hideall statements: they would change the cactbot file's).
/// </para>
/// <para>
/// Optional per mechanic, for the automatic press times of calls planned there without a time
/// (<see cref="Reminders.TimingRules.ForEntry"/>): <c>press: after</c> (<see cref="Mechanic.PressAfter"/>: pressed after
/// the hit, like heals), <c>heal_lead</c> (<see cref="Mechanic.HealLead"/>: seconds before the hit for heals; positive,
/// and not with <c>press: after</c>) and <c>series: true</c> (<see cref="Mechanic.Series"/>: a call for a later hit is
/// pressed after the hit before it; at least two hits).
/// </para>
/// </remarks>
public static class FightLoader
{
    private static readonly string KindNames = string.Join(", ", Enum.GetNames<MechanicKind>().Select(ToSnakeCase));

    /// <summary>Parses one fight YAML document. Throws <see cref="FormatException"/> with a helpful message on invalid data.</summary>
    /// <param name="yaml">The document.</param>
    /// <param name="sourceName">File name for messages (e.g. "fights/top.yaml"); optional.</param>
    public static FightDefinition Load(string yaml, string? sourceName = null)
    {
        ArgumentNullException.ThrowIfNull(yaml);
        var root = YamlNodes.LoadMapping(yaml, sourceName ?? "fight file");

        var key = YamlNodes.RequireString(root, "fight", sourceName ?? "fight file");
        var context = sourceName ?? $"fight '{key}'";

        var territory = YamlNodes.RequireInteger(root, "territory", context);
        if (territory is < 1 or > ushort.MaxValue)
            throw new FormatException($"{context}: 'territory' must be a TerritoryType id between 1 and {ushort.MaxValue}, not {territory}.");
        var syncLevel = YamlNodes.RequireInteger(root, "sync_level", context);
        if (syncLevel is < 1 or > 200)
            throw new FormatException($"{context}: 'sync_level' must be a level such as 80, 90 or 100, not {syncLevel}.");

        var phases = ReadPhases(root, context);
        var mechanics = ReadMechanics(root, context, phases);

        return new FightDefinition
        {
            Key = key,
            Name = YamlNodes.RequireString(root, "name", context),
            Territory = (ushort)territory,
            SyncLevel = (int)syncLevel,
            TimelineFile = YamlNodes.RequireString(root, "timeline", context),
            TimelineAdditions = ReadTimelineAdditions(root, context),
            Phases = phases,
            Mechanics = mechanics.OrderBy(m => m.Hit).ToList(),
            Calibration = ReadCalibration(root, context),
            RowOffsets = ReadRowOffsets(root, context, mechanics),
        };
    }

    /// <summary>Parses a mechanic kind written in snake_case ("lb_check"); also accepts PascalCase and dashes/spaces.</summary>
    public static bool TryParseKind(string? text, out MechanicKind kind)
    {
        kind = MechanicKind.Other;
        var compact = new string((text ?? string.Empty).Where(char.IsLetterOrDigit).ToArray());
        return compact.Length > 0 && char.IsLetter(compact[0]) &&
               Enum.TryParse(compact, ignoreCase: true, out kind) && Enum.IsDefined(kind);
    }

    /// <summary>The snake_case spelling used in fight files ("LbCheck" → "lb_check").</summary>
    public static string KindName(MechanicKind kind) => ToSnakeCase(kind.ToString());

    /// <summary>
    /// The optional <c>timeline_additions</c> (<see cref="FightDefinition.TimelineAdditions"/>): cactbot timeline lines,
    /// each an entry with a sync (comments allowed), without jumps to labels and without label or hideall statements (the
    /// labels and names are the cactbot file's).
    /// </summary>
    private static string? ReadTimelineAdditions(YamlMappingNode root, string context)
    {
        var text = YamlNodes.GetString(root, "timeline_additions", context);
        if (string.IsNullOrWhiteSpace(text))
            return null;

        var where = $"{context}: timeline_additions";
        Timeline parsed;
        try
        {
            parsed = TimelineParser.Parse(text, where);
        }
        catch (FormatException ex)
        {
            throw new FormatException(ex.Message, ex);
        }

        // Appended to the cactbot file, a label would redefine the file's label of that name (the parser keeps the last one)
        // and a hideall would hide its entries: only entries are added.
        if (parsed.Labels.Count > 0)
            throw new FormatException($"{where}: label \"{parsed.Labels.Keys.First()}\" (only sync lines can be added: the labels are the cactbot file's).");
        if (parsed.HiddenNames.Count > 0)
            throw new FormatException($"{where}: hideall \"{parsed.HiddenNames.First()}\" (only sync lines can be added).");
        if (parsed.Entries.FirstOrDefault(e => e.JumpLabel != null) is { } jump)
            throw new FormatException($"{where}: line {jump.Line} (\"{jump.Name}\") jumps to a label (use a time: the labels are the cactbot file's).");
        if (parsed.Warnings.Count > 0)
            throw new FormatException($"{where}: {parsed.Warnings[0]}.");
        if (parsed.Entries.FirstOrDefault(e => !e.CanSync) is { } bad)
            throw new FormatException($"{where}: line {bad.Line} (\"{bad.Name}\") has no sync (only sync lines can be added).");

        return text;
    }

    private static List<Phase> ReadPhases(YamlMappingNode root, string context)
    {
        var phases = new List<Phase>();
        var lines = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        var list = YamlNodes.GetList(root, "phases", context);
        for (var i = 0; i < list.Count; i++)
        {
            if (list[i] is not YamlMappingNode node)
                throw new FormatException($"{context}: phases[{i}] must be a mapping such as {{id: p1, name: \"P1\", start: 0}} ({YamlNodes.Where(list[i])}).");
            var id = YamlNodes.RequireString(node, "id", $"{context}: phases[{i}]");
            var phaseContext = $"{context}: phase '{id}'";
            if (lines.TryGetValue(id, out var firstLine))
                throw new FormatException($"{phaseContext}: duplicate phase id ({YamlNodes.Where(node)}; first defined on line {firstLine}).");
            lines[id] = node.Start.Line;

            phases.Add(new Phase
            {
                Id = id,
                Name = YamlNodes.GetString(node, "name", phaseContext)?.Trim() is { Length: > 0 } name ? name : id,
                Start = YamlNodes.RequireDouble(node, "start", phaseContext),
            });
        }
        return phases;
    }

    private static List<Mechanic> ReadMechanics(YamlMappingNode root, string context, List<Phase> phases)
    {
        var mechanics = new List<Mechanic>();
        var lines = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        var phaseIds = new HashSet<string>(phases.Select(p => p.Id), StringComparer.OrdinalIgnoreCase);
        var list = YamlNodes.GetList(root, "mechanics", context);
        for (var i = 0; i < list.Count; i++)
        {
            if (list[i] is not YamlMappingNode node)
                throw new FormatException($"{context}: mechanics[{i}] must be a mapping ({YamlNodes.Where(list[i])}).");
            var id = YamlNodes.RequireString(node, "id", $"{context}: mechanics[{i}]");
            var m = $"{context}: mechanic '{id}' ({YamlNodes.Where(node)})";
            if (lines.TryGetValue(id, out var firstLine))
                throw new FormatException($"{m}: duplicate mechanic id (first defined on line {firstLine}).");
            lines[id] = node.Start.Line;

            var (hit, hits) = ReadHits(node, m);
            var subHits = ReadSubHits(node, m, hit, hits);

            var phase = YamlNodes.GetString(node, "phase", m)?.Trim();
            if (string.IsNullOrEmpty(phase))
            {
                phase = phases.Where(p => p.Start <= hit).OrderBy(p => p.Start).LastOrDefault()?.Id
                    ?? throw new FormatException($"{m}: 'phase' is missing and no phase starts at or before its hit ({hit}).");
            }
            else if (!phaseIds.Contains(phase))
            {
                throw new FormatException($"{m}: unknown phase '{phase}' (phases: {(phaseIds.Count == 0 ? "none defined" : string.Join(", ", phases.Select(p => p.Id)))}).");
            }
            else
            {
                phase = phases.First(p => string.Equals(p.Id, phase, StringComparison.OrdinalIgnoreCase)).Id;
            }

            var kind = MechanicKind.Other;
            if (YamlNodes.GetString(node, "kind", m) is { } kindText && !TryParseKind(kindText, out kind))
                throw new FormatException($"{m}: unknown kind '{kindText}' (expected {KindNames}).");

            var press = YamlNodes.GetString(node, "press", m)?.Trim();
            if (press is not null && !string.Equals(press, "after", StringComparison.OrdinalIgnoreCase))
                throw new FormatException($"{m}: unknown press '{press}' (expected after: calls without a time are pressed after the hit).");
            var healLead = YamlNodes.GetDouble(node, "heal_lead", m);
            if (healLead is { } lead && lead <= 0)
                throw new FormatException($"{m}: 'heal_lead' must be a positive number of seconds before the hit, not {lead.ToString(CultureInfo.InvariantCulture)}.");
            if (healLead is not null && press is not null)
                throw new FormatException($"{m}: 'heal_lead' and 'press: after' contradict each other (heals before the hit, every call after it).");
            var series = YamlNodes.GetBool(node, "series", m) ?? false;
            if (series && hits.Count < 2)
                throw new FormatException($"{m}: 'series' needs at least two hits (a call for a later hit is pressed after the hit before it).");

            var entry = YamlNodes.GetString(node, "entry", m);
            var name = YamlNodes.GetString(node, "name", m)?.Trim();
            mechanics.Add(new Mechanic
            {
                Id = id,
                Name = !string.IsNullOrEmpty(name) ? name : !string.IsNullOrWhiteSpace(entry) ? entry.Trim() : id,
                Phase = phase,
                Hit = hit,
                Hits = hits,
                SubHits = subHits,
                Entry = string.IsNullOrEmpty(entry) ? null : entry,
                Kind = kind,
                Aliases = YamlNodes.GetStringList(node, "aliases", m),
                PressAfter = press is not null,
                HealLead = healLead,
                Series = series,
            });
        }
        return mechanics;
    }

    /// <summary>hit and hits: hits default to [hit]; hit defaults to hits[0]; hits must be in time order and start with hit.</summary>
    private static (double Hit, IReadOnlyList<double> Hits) ReadHits(YamlMappingNode node, string context)
    {
        const double tolerance = 1e-6;
        var hit = YamlNodes.GetDouble(node, "hit", context);
        var hits = YamlNodes.GetDoubleList(node, "hits", context);
        if (hits.Count == 0)
        {
            if (hit is not { } single)
                throw new FormatException($"{context}: 'hit' is missing.");
            return (single, [single]);
        }

        for (var i = 1; i < hits.Count; i++)
        {
            if (hits[i] < hits[i - 1])
                throw new FormatException($"{context}: 'hits' must be in time order ({hits[i - 1]} comes before {hits[i]}).");
        }

        if (hit is { } first && Math.Abs(first - hits[0]) > tolerance)
        {
            throw new FormatException(hits.Any(h => Math.Abs(h - first) <= tolerance)
                ? $"{context}: 'hit' ({first}) must be the first of 'hits' ({hits[0]}): 'hit' is the first damage."
                : $"{context}: 'hit' ({first}) is not one of 'hits' ([{string.Join(", ", hits)}]).");
        }
        return (hits[0], hits);
    }

    /// <summary>
    /// The optional <c>sub_hits</c> (<see cref="Mechanic.SubHits"/>): each after <paramref name="hit"/>, in time order, and
    /// none of them one of <paramref name="hits"/> (a damage time with a timeline entry is a hit).
    /// </summary>
    private static IReadOnlyList<double> ReadSubHits(YamlMappingNode node, string context, double hit, IReadOnlyList<double> hits)
    {
        const double tolerance = 1e-6;
        var subHits = YamlNodes.GetDoubleList(node, "sub_hits", context);
        for (var i = 0; i < subHits.Count; i++)
        {
            var time = subHits[i].ToString(CultureInfo.InvariantCulture);
            if (subHits[i] <= hit + tolerance)
                throw new FormatException($"{context}: 'sub_hits' are damage times after 'hit' ({hit.ToString(CultureInfo.InvariantCulture)}), not {time}.");
            if (i > 0 && subHits[i] <= subHits[i - 1] + tolerance)
                throw new FormatException($"{context}: 'sub_hits' must be in time order ({subHits[i - 1].ToString(CultureInfo.InvariantCulture)} comes before {time}).");
            if (hits.Any(h => Math.Abs(h - subHits[i]) <= tolerance))
                throw new FormatException($"{context}: 'sub_hits' has {time}, one of 'hits' (a damage time with a timeline entry is a hit).");
        }

        return subHits;
    }

    private static IReadOnlyDictionary<string, IReadOnlyDictionary<string, double>> ReadCalibration(YamlMappingNode root, string context)
    {
        var result = new Dictionary<string, IReadOnlyDictionary<string, double>>(StringComparer.OrdinalIgnoreCase);
        var node = YamlNodes.Get(root, "calibration");
        if (node == null)
            return result;
        if (node is not YamlMappingNode presets)
            throw new FormatException($"{context}: 'calibration' must be a mapping of sheet keys to phase zero points ({YamlNodes.Where(node)}).");

        foreach (var (sheet, sheetNode, value) in YamlNodes.Entries(presets))
        {
            var c = $"{context}: calibration '{sheet}'";
            if (YamlNodes.IsNull(value))
                continue;
            if (value is not YamlMappingNode zeros)
                throw new FormatException($"{c}: must be a mapping of phase ids to timeline seconds, e.g. {{p1: 0.0, p2: 202.0}} ({YamlNodes.Where(sheetNode)}).");
            var points = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var (phase, _, zero) in YamlNodes.Entries(zeros))
            {
                if (!YamlNodes.IsNull(zero))
                    points[phase] = YamlNodes.ToDouble(zero, $"the zero point of '{phase}'", c);
            }
            result[sheet] = points;
        }
        return result;
    }

    /// <summary>Optional <c>row_offsets</c>: sheet key → {mechanic id: seconds}; the mechanic ids must exist.</summary>
    private static IReadOnlyDictionary<string, IReadOnlyDictionary<string, double>> ReadRowOffsets(YamlMappingNode root, string context, List<Mechanic> mechanics)
    {
        var result = new Dictionary<string, IReadOnlyDictionary<string, double>>(StringComparer.OrdinalIgnoreCase);
        var node = YamlNodes.Get(root, "row_offsets");
        if (node == null || YamlNodes.IsNull(node))
            return result;
        if (node is not YamlMappingNode sheets)
            throw new FormatException($"{context}: 'row_offsets' must be a mapping of sheet keys to {{mechanic id: seconds}} ({YamlNodes.Where(node)}).");

        var ids = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var m in mechanics)
            ids[m.Id] = m.Id;
        foreach (var (sheet, sheetNode, value) in YamlNodes.Entries(sheets))
        {
            var c = $"{context}: row_offsets '{sheet}'";
            if (YamlNodes.IsNull(value))
                continue;
            if (value is not YamlMappingNode offsets)
                throw new FormatException($"{c}: must be a mapping of mechanic ids to seconds, e.g. {{p5.blind_faith: -1.2}} ({YamlNodes.Where(sheetNode)}).");
            var map = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var (id, idNode, seconds) in YamlNodes.Entries(offsets))
            {
                if (!ids.TryGetValue(id, out var canonical))
                    throw new FormatException($"{c}: unknown mechanic '{id}' ({YamlNodes.Where(idNode)}).");
                if (!YamlNodes.IsNull(seconds))
                    map[canonical] = YamlNodes.ToDouble(seconds, $"the row offset of '{id}'", c);
            }
            result[sheet] = map;
        }
        return result;
    }

    private static string ToSnakeCase(string pascal)
    {
        var sb = new StringBuilder(pascal.Length + 4);
        for (var i = 0; i < pascal.Length; i++)
        {
            if (char.IsUpper(pascal[i]) && i > 0)
                sb.Append('_');
            sb.Append(char.ToLowerInvariant(pascal[i]));
        }
        return sb.ToString();
    }
}
