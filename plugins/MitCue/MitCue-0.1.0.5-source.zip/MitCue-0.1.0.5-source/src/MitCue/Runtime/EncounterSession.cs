using MitCue.Core.Actions;
using MitCue.Core.Events;
using MitCue.Core.Fights;
using MitCue.Core.Plans;
using MitCue.Core.Reminders;
using MitCue.Core.Timelines;
using MitCue.Util;

namespace MitCue.Runtime;

/// <summary>Where an <see cref="EncounterSession"/> is in a pull.</summary>
internal enum SessionMode
{
    /// <summary>No pull, no countdown: nothing to show.</summary>
    Idle,

    /// <summary>A /countdown is running: reminders use timeline time = −remaining.</summary>
    Countdown,

    /// <summary>The pull is on (timeline running, or ended while still in combat).</summary>
    Running,
}

/// <summary>Everything needed to start an <see cref="EncounterSession"/>.</summary>
internal sealed class SessionSetup
{
    /// <summary>The fight.</summary>
    public required FightDefinition Fight { get; init; }

    /// <summary>The fight's parsed timeline.</summary>
    public required Timeline Timeline { get; init; }

    /// <summary>The active plan.</summary>
    public required MitPlan Plan { get; init; }

    /// <summary>Who the player is (job, level, slot, column).</summary>
    public required PlayerContext Me { get; init; }

    /// <summary>The player's own entries.</summary>
    public required IReadOnlyList<PlanEntry> OwnEntries { get; init; }

    /// <summary>Other columns' entries (shown dimmed), or null.</summary>
    public IReadOnlyList<PlanEntry>? OtherEntries { get; init; }

    /// <summary>Action catalog for timing defaults.</summary>
    public required IActionCatalog Actions { get; init; }

    /// <summary>Scheduler options (updated in place on config edits).</summary>
    public required ReminderOptions Options { get; init; }

    /// <summary>Timeline sync options.</summary>
    public required SyncMatchOptions SyncOptions { get; init; }

    /// <summary>True for <c>/mitcue preview</c> sessions.</summary>
    public bool IsPreview { get; init; }

    /// <summary>Creates the sync engine; null for the core <see cref="TimelinePlayer"/> (tests pass a scripted one).</summary>
    public Func<Timeline, SyncMatchOptions, ISyncEngine>? Engine { get; init; }
}

/// <summary>
/// Runtime state for one fight + plan + player: a <see cref="TimelinePlayer"/> fed with game events and a
/// <see cref="ReminderScheduler"/> (plus an optional one for other columns) advanced from timeline time,
/// own action uses and cooldowns. Handles pre-pull countdowns, pull end (wipe, duty or timeline reset,
/// prolonged out-of-combat, combat end once the timeline has stopped) and the pull summary. Core calls may
/// throw; the owner catches.
/// </summary>
internal sealed class EncounterSession
{
    /// <summary>Seconds out of combat (while the timeline runs) after which the pull is considered over.</summary>
    public const double OutOfCombatResetSeconds = 10;

    /// <summary>Pull-end reason when a timeline sync stopped the timeline (a jump to 0).</summary>
    private const string TimelineResetReason = "timeline reset";

    /// <summary>A countdown that stops with more than this many seconds left was cancelled.</summary>
    private const float CountdownCancelledAbove = 1f;

    /// <summary>How long pre-pull reminders stay after a countdown reached zero without a pull.</summary>
    private const double PullGraceAfterCountdown = 20;

    private static readonly IReadOnlyList<Reminder> NoReminders = [];

    private bool syncedDuringTick;
    private bool timelineReset;
    private double lastInCombatClock;
    private double lastNpcActivityClock;
    private float lastCountdown;
    private double prePullTime;
    private double prePullClock;
    private double? countdownEndedClock;

    /// <summary>Creates the timeline player and schedulers (may throw while the core is incomplete).</summary>
    public EncounterSession(SessionSetup setup)
    {
        this.Fight = setup.Fight;
        this.Plan = setup.Plan;
        this.Me = setup.Me;
        this.Options = setup.Options;
        this.IsPreview = setup.IsPreview;
        this.OwnEntryCount = setup.OwnEntries.Count;
        this.OtherEntryCount = setup.OtherEntries?.Count ?? 0;

        // The session ends the pull after a prolonged out-of-combat (Update), so the engine must not stop the moment
        // the combat flag drops (TimelineSyncEngine builds the player with StopOnCombatEnd = false).
        this.Player = setup.Engine?.Invoke(setup.Timeline, setup.SyncOptions) ?? new TimelineSyncEngine(setup.Timeline, setup.SyncOptions);
        this.Player.Synced += this.OnSynced;

        this.Scheduler = new ReminderScheduler(setup.Fight, setup.OwnEntries, setup.Actions, setup.Options);
        this.Scheduler.BecameDue += this.OnBecameDue;

        if (setup.OtherEntries is { Count: > 0 } others)
            this.Others = new ReminderScheduler(setup.Fight, others, setup.Actions, setup.Options);

        var ids = new HashSet<uint>();
        foreach (var entry in setup.OwnEntries)
        {
            foreach (var item in entry.Do)
            {
                // A null item (possible in plans built in code) must not stop the whole session from starting.
                if (item == null)
                    continue;
                foreach (var id in item.ActionIds())
                    ids.Add(id);
            }
        }

        this.TrackedActionIds = ids;
    }

    /// <summary>Raised when a pull ends with something to report (summary, reason).</summary>
    public event Action<EncounterSession, PullSummary, string>? PullEnded;

    /// <summary>Raised when one of the player's own reminders becomes due.</summary>
    public event Action<EncounterSession, Reminder>? BecameDue;

    /// <summary>The fight.</summary>
    public FightDefinition Fight { get; }

    /// <summary>The plan.</summary>
    public MitPlan Plan { get; }

    /// <summary>The player context used to select entries.</summary>
    public PlayerContext Me { get; }

    /// <summary>Scheduler options (shared with the schedulers; edited in place).</summary>
    public ReminderOptions Options { get; }

    /// <summary>True for preview sessions.</summary>
    public bool IsPreview { get; }

    /// <summary>Number of the player's entries.</summary>
    public int OwnEntryCount { get; }

    /// <summary>Number of other columns' entries shown dimmed.</summary>
    public int OtherEntryCount { get; }

    /// <summary>The sync engine.</summary>
    public ISyncEngine Player { get; }

    /// <summary>The player's reminders.</summary>
    public ReminderScheduler Scheduler { get; }

    /// <summary>Other columns' reminders, or null.</summary>
    public ReminderScheduler? Others { get; }

    /// <summary>Action ids of the player's entries (for the cooldown usage fallback).</summary>
    public HashSet<uint> TrackedActionIds { get; }

    /// <summary>Current mode.</summary>
    public SessionMode Mode { get; private set; }

    /// <summary>Timeline time of the last update (negative during a countdown).</summary>
    public double TimelineTime { get; private set; }

    /// <summary>Remaining countdown seconds of the last update (0 without a countdown).</summary>
    public float CountdownRemaining { get; private set; }

    /// <summary>True from the timeline start until the pull ends.</summary>
    public bool PullActive { get; private set; }

    /// <summary>
    /// True during a pull, between the countdown's end and the pull (the pre-pull reminders are held then), and during a
    /// countdown once a call (the player's or a partner's) is shown or done: settings and party changes wait until it is
    /// over, so a rebuild never drops a pre-pull call already shown or done. Before that a countdown loses nothing to a
    /// rebuild (the new session takes the countdown up on its first update), so a co-tank who shows up in the party list
    /// after /countdown still gets the player their tank pair's column for the pull. A timeline this frame's events
    /// started (the pull's InCombat edge, fed before the session's update sets <see cref="PullActive"/>) counts as the
    /// pull: a session rebuilt then would never see that edge and would not follow the pull.
    /// </summary>
    public bool IsBusy =>
        this.PullActive
        || this.Player.IsRunning
        || this.countdownEndedClock != null
        || (this.Mode == SessionMode.Countdown && (this.AnyReminderTouched() || (this.Others != null && AnyTouched(this.Others))));

    /// <summary>The player's reminders to display, ordered by press time.</summary>
    public IReadOnlyList<Reminder> Visible { get; private set; } = NoReminders;

    /// <summary>Other columns' reminders to display, ordered by press time.</summary>
    public IReadOnlyList<Reminder> VisibleOthers { get; private set; } = NoReminders;

    /// <summary>Recent syncs for the Debug tab.</summary>
    public RingBuffer<SyncResult> Syncs { get; } = new(20);

    /// <summary>Number of timeline jumps forwarded to the scheduler.</summary>
    public int Jumps { get; private set; }

    /// <summary>Own uses forwarded to the scheduler.</summary>
    public int OwnUses { get; private set; }

    /// <summary>Feeds one game event (in clock order).</summary>
    /// <remarks>
    /// While a pull is on, InCombat edges are not passed to the timeline player: cactbot's playback stops the timeline
    /// when combat ends, but a dead player can lose the flag while the fight goes on, and the InCombat sync would then
    /// restart the timeline at 0 after the raise. Such a pull ends through <see cref="DutyReset"/> or the
    /// prolonged out-of-combat rule in <see cref="Update"/> instead (DESIGN §4).
    /// </remarks>
    public void Process(GameEvent e)
    {
        if (e is CastStarted or AbilityResolved { SourceIsPlayer: false })
            this.lastNpcActivityClock = Math.Max(this.lastNpcActivityClock, e.Time);

        if (e is CombatStateChanged && this.PullActive)
            return;

        this.Player.Process(e);
        if (e is DutyReset reset)
            this.EndPull(Describe(reset.Kind));
        else if (this.TakeTimelineReset())
            this.EndPull(TimelineResetReason);
    }

    /// <summary>The local player used an action at <paramref name="clock"/>.</summary>
    public void OnOwnUse(uint actionId, double clock)
    {
        if (!this.TryTimelineTimeAt(clock, out var t))
            return;
        this.Scheduler.OnOwnAction(actionId, t);
        this.OwnUses++;
    }

    /// <summary>Another player used an action (only marks other columns' reminders).</summary>
    public void OnPartyUse(uint actionId, double clock)
    {
        if (this.Others != null && this.TryTimelineTimeAt(clock, out var t))
            this.Others.OnOwnAction(actionId, t);
    }

    /// <summary>Advances the timeline and the reminders to <paramref name="now"/>.</summary>
    /// <param name="now">Clock (monotonic seconds; simulated in previews).</param>
    /// <param name="countdown">Remaining /countdown seconds, or null.</param>
    /// <param name="inCombat">The InCombat condition.</param>
    /// <param name="cooldowns">Cooldown provider for the player's reminders (null in previews).</param>
    public void Update(double now, float? countdown, bool inCombat, ICooldownProvider? cooldowns)
    {
        // Tick: forcejumps and auto-stop. Detect jumps that happened without a Synced event.
        var before = this.Player.TimeAt(now);
        var wasRunning = this.Player.IsRunning;
        this.syncedDuringTick = false;
        this.Player.Tick(now);
        if (this.TakeTimelineReset())
        {
            this.EndPull(TimelineResetReason); // a forcejump to 0
            return;
        }

        var running = this.Player.IsRunning;
        if (wasRunning && running && !this.syncedDuringTick)
        {
            var after = this.Player.TimeAt(now);
            if (Math.Abs(after - before) > 5)
                this.Jump(before, after);
        }

        if (running && !this.PullActive)
        {
            this.PullActive = true;
            this.countdownEndedClock = null;
            this.lastInCombatClock = now;
        }

        if (inCombat || !this.PullActive)
            this.lastInCombatClock = now;

        if (this.PullActive)
        {
            // Prolonged out-of-combat (DESIGN §4). Enemy activity keeps the pull alive: a dead player
            // may lose the InCombat flag while the fight goes on.
            if (running && !inCombat
                && now - this.lastInCombatClock > OutOfCombatResetSeconds
                && now - this.lastNpcActivityClock > OutOfCombatResetSeconds)
            {
                this.EndPull("out of combat");
                return;
            }

            // The timeline stopped by itself (never on a mid-pull combat edge, see Process) and combat is over.
            if (!running && !inCombat)
            {
                this.EndPull("combat ended");
                return;
            }
        }

        double t;
        if (this.PullActive)
        {
            // Running, or the timeline ended while still in combat (time stays frozen at its end).
            this.Mode = SessionMode.Running;
            this.CountdownRemaining = 0;
            t = this.Player.TimeAt(now);
        }
        else if (countdown is { } remaining)
        {
            if (this.Mode != SessionMode.Countdown || remaining > this.lastCountdown + 0.5f)
                this.ResetReminders(); // a new (or restarted) countdown starts from a clean slate

            this.Mode = SessionMode.Countdown;
            this.CountdownRemaining = remaining;
            this.lastCountdown = remaining;
            this.countdownEndedClock = null;
            t = -remaining;
            this.prePullTime = t;
            this.prePullClock = now;
        }
        else
        {
            if (this.Mode == SessionMode.Countdown)
            {
                if (this.lastCountdown > CountdownCancelledAbove)
                    this.ResetReminders(); // cancelled
                else
                    this.countdownEndedClock = now; // reached zero: the pull should follow
            }

            this.Mode = SessionMode.Idle;
            this.CountdownRemaining = 0;
            if (this.countdownEndedClock is not { } ended)
            {
                this.Visible = NoReminders;
                this.VisibleOthers = NoReminders;
                return;
            }

            if (now - ended > PullGraceAfterCountdown)
            {
                this.countdownEndedClock = null;
                this.ResetReminders();
                return;
            }

            // Between "0" and the pull: hold at time 0 so nothing is judged before the fight starts.
            t = Math.Min(0, this.prePullTime + (now - this.prePullClock));
        }

        this.TimelineTime = t;
        this.Visible = this.Scheduler.Update(t, cooldowns);
        this.VisibleOthers = this.Others?.Update(t) ?? NoReminders;
    }

    /// <summary>Ends the pull without a summary and rewinds everything (<c>/mitcue reset</c>).</summary>
    public void ManualReset() => this.ResetAll();

    /// <summary>
    /// Marks every reminder planned before timeline time <paramref name="time"/> as skipped. A phase preview starts the
    /// fight at that phase: the earlier reminders were never shown, so they must not be judged missed at the pull.
    /// </summary>
    public void SkipBefore(double time)
    {
        var last = Math.BitDecrement(time);
        this.Scheduler.OnTimelineJump(double.NegativeInfinity, last);
        this.Others?.OnTimelineJump(double.NegativeInfinity, last);
    }

    /// <summary>Ends the pull: raises <see cref="PullEnded"/> when anything happened, then rewinds.</summary>
    public void EndPull(string reason)
    {
        PullSummary? summary = null;
        if (this.PullActive || this.AnyReminderTouched())
            summary = this.Scheduler.Summarize();

        this.ResetAll();
        if (summary != null)
            this.PullEnded?.Invoke(this, summary, reason);
    }

    /// <summary>The phase containing timeline time <paramref name="t"/>, without allocating.</summary>
    public Phase? PhaseAt(double t)
    {
        Phase? best = null;
        foreach (var phase in this.Fight.Phases)
        {
            if (phase.Start <= t && (best == null || phase.Start >= best.Start))
                best = phase;
        }

        return best;
    }

    private static string Describe(DutyResetKind kind) => kind switch
    {
        DutyResetKind.Wipe => "wipe",
        DutyResetKind.Recommence => "duty recommenced",
        DutyResetKind.Completed => "cleared",
        DutyResetKind.LeftZone => "left the zone",
        _ => kind.ToString(),
    };

    private bool TryTimelineTimeAt(double clock, out double t)
    {
        if (this.PullActive || this.Player.IsRunning)
        {
            t = this.Player.TimeAt(clock);
            return true;
        }

        if (this.Mode == SessionMode.Countdown || this.countdownEndedClock != null)
        {
            t = Math.Min(0, this.prePullTime + (clock - this.prePullClock));
            return true;
        }

        t = 0;
        return false;
    }

    private bool AnyReminderTouched() => AnyTouched(this.Scheduler);

    /// <summary>True when a reminder of <paramref name="scheduler"/> has left <see cref="ReminderState.Pending"/> (shown or finished).</summary>
    private static bool AnyTouched(ReminderScheduler scheduler)
    {
        foreach (var r in scheduler.All)
        {
            if (r.State != ReminderState.Pending)
                return true;
        }

        return false;
    }

    private void ResetReminders()
    {
        this.Scheduler.Reset();
        this.Others?.Reset();
        this.Visible = NoReminders;
        this.VisibleOthers = NoReminders;
    }

    private void ResetAll()
    {
        this.Player.Reset();
        this.ResetReminders();
        this.PullActive = false;
        this.Mode = SessionMode.Idle;
        this.TimelineTime = 0;
        this.CountdownRemaining = 0;
        this.lastCountdown = 0;
        this.countdownEndedClock = null;
    }

    /// <summary>
    /// Forwards a timeline jump (a sync that moved time by more than 5 s, <see cref="SyncResult.IsJump"/>, or a jump
    /// seen by a tick) to the schedulers: reminders a phase push jumped over are skipped, and the phase-end reminders
    /// of the phase it ended become due at once (DESIGN §5.2; their sound plays on the next <see cref="Update"/>).
    /// A timeline start comes here from −∞ (see <see cref="OnSynced"/>).
    /// </summary>
    private void Jump(double from, double to)
    {
        this.Scheduler.OnTimelineJump(from, to);
        this.Others?.OnTimelineJump(from, to);
        this.Jumps++;
    }

    /// <summary>True once after a sync stopped the timeline (a jump to 0) during the pull.</summary>
    private bool TakeTimelineReset()
    {
        var reset = this.timelineReset && this.PullActive;
        this.timelineReset = false;
        return reset;
    }

    private void OnSynced(SyncResult result)
    {
        this.syncedDuringTick = true;
        this.Syncs.Add(result);
        if (result.Stopped)
        {
            // A jump to 0 (cactbot's --Reset--, the wipe's fade-in) ends the pull; the caller ends it once the
            // player is done. It is not a jump back to 0: that would put every missed and skipped reminder back
            // to Pending before the summary.
            this.timelineReset = true;
            return;
        }

        // A sync that started the stopped timeline (e.g. a pull joined mid-fight: the plugin was loaded in combat, so there
        // was no InCombat edge) does not come from time 0, whatever FromTime says: it is forwarded as a jump from −∞, which
        // skips the reminders it passed and never makes a phase-end call due (DESIGN §5.2). A start at the pull (InCombat,
        // time 0) is no jump.
        if (result.IsJump)
            this.Jump(result.Started ? double.NegativeInfinity : result.FromTime, result.ToTime);
    }

    private void OnBecameDue(Reminder reminder) => this.BecameDue?.Invoke(this, reminder);
}
